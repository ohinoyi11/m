<?php 
include_once ('config.php');
include_once ('session.php');

    if(isset($_POST[''])) {
        echo "success";
    }

?>